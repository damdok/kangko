﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This is used to remove overlapping Images:
public class TestDecal : MonoBehaviour
{

    public static TestDecal instance = null;

    bool placeable = true;

    //Awake is always called before any Start functions
    void Awake()
    {
        //Check if instance already exists
        if (instance == null)
        {
            //if not, set instance to this
            instance = this;
        }

        //If instance already exists and it's not this:
        else if (instance != this)
        {
            //Then destroy this. This enforces our singleton pattern, meaning there can only ever be one instance of a TestDecal.
            Destroy(gameObject);
        }
    }

    public bool CanPlace()
    {
        return placeable;
    }

    public void SetPlace(bool place)
    {
        placeable = place;
    }

    // Does it collide with another Image:
    /*
    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Decal"))
        {
            placeable = false;
        }
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Decal"))
        {
            placeable = true;
        }
    }
    */




}
