﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Inventory : MonoBehaviour
{
    [Header("Input Fields")]
    [SerializeField] InputField scale;
    [SerializeField] InputField rotation;

    [Header("Inventory UI")]
    public GameObject invUI;

    Sprite[] sprites;

    public GameObject imageTemplace;

    private void Start()
    {
        sprites = PlaceImage.instance.listOfImages;
        AddSprites();
        invUI.SetActive(false);
    }

    // Get all the sprites from the spritesheet:
    void AddSprites()
    {
        int counter = 0;

        // For each sprite in the spriteSheet:
        foreach(Sprite sprite in sprites)
        {
            // Create a new Image with the sprite:
            GameObject newImage = Instantiate(imageTemplace, this.transform) as GameObject;
            newImage.SetActive(true);
            newImage.GetComponent<Image>().sprite = sprite;
            // Store that image as a counter number so it matches the sprite location:
            newImage.name = counter.ToString();
            counter++;

        }
    }

    // When the user clicks on the Image:
    public void OnImagePress(GameObject img)
    {
        // Set currentSprite to the image name:
        PlaceImage.instance.currentSprite = int.Parse(img.name);
        // Set the sprite:
        PlaceImage.instance.testDecal.Sprite = img.GetComponent<Image>().sprite;
    }
    
    // Exit the Game:
    public void OnExitPress()
    {
        Application.Quit();
    }

    // Resume the Game:
    public void OnResumePress()
    {
        // Hide UI:
        invUI.SetActive(false);
        PlaceImage.instance.openUI = false;
        // Hide Mouse:
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;
        // Unpause game:
        Time.timeScale = 1;
    }

    // Fill in the input field:
    public void SetValuescale(float scaler)
    {
        scale.text = scaler.ToString();
    }

    // Setting the value of the scale by user Input:
    public void GetValuescale()
    {
        // Try convert to float:
        try
        {
            float newScale = float.Parse(scale.text);
            // Limit the scale:
            newScale = Mathf.Clamp(newScale, 0, 5);
            // Set the Scale:
            PlaceImage.instance.scaler = newScale;
        }
        catch
        {
            scale.text = "0";
        }
    }

    // Fill in the input field:
    public void SetValueRotation(float rotations)
    {
        rotation.text = rotations.ToString();
    }

    // Setting the value of the rotation by user Input:
    public void GetValueRotation()
    {
        // Try convert to float:
        try
        {
            float newRotation = float.Parse(rotation.text);
            // Limit the rotation
            newRotation = Mathf.Clamp(newRotation, -360, 360);
            // Set the Rotation:
            PlaceImage.instance.rotation = newRotation;
        }
        catch
        {
            rotation.text = "0";
        }
    }

}
