﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// This Script deals with Player Movement and Rotation.
/// </summary>
[RequireComponent (typeof(Rigidbody))]
public class PlayerMovement : MonoBehaviour {

    // Movement and Rotation Speed of the Player:
    [Header("Movement Settings")]
    [SerializeField] float movementSpeed;
    [SerializeField] float mouseSensitivity;

    // Capping the Player so they can't look all the way under them or over:
    [Range (0,90)]
    [SerializeField] float mouseYLock = 60f;

    PlaceImage image;
    Rigidbody rb;

    // Use this for initialization
    void Start ()
    {
        // Grab the image placement:
        image = GetComponent<PlaceImage>();

        // Hide and Lock Mouse:
        Cursor.visible = false;
        Cursor.lockState = CursorLockMode.Locked;

        // Grab the Rigidbody:
        rb = GetComponent<Rigidbody>();
	}

    // Update is called once per frame
	void Update ()
    {
        // If the UI isn't open:
        if (!PlaceImage.instance.openUI)
        {
            // Check if the User is trying to move. If so, move:
            MovementControls();

            // Is the User not trying to rotate the Image:
            if(!image.isRotating)
            {
                // Check if the User is trying to rotate. If so, rotate:
                MouseControls();
            }

            // Check If the User wants to exit the game:
            Exit();
        }


    }


    /// <summary>
    ///  Deals with the movement of the player
    /// </summary>
    void MovementControls()
    {
        // Player Input:
        float horInput = Input.GetAxis("Horizontal") * movementSpeed * Time.deltaTime;
        float verInput = Input.GetAxis("Vertical") * movementSpeed * Time.deltaTime;

        // Movement:
        Vector3 newPosition = transform.position + (transform.right * horInput) + (transform.forward * verInput);
        rb.MovePosition(newPosition);
    }


    // Default Rotation:
    float yInput = 0;
    float xInput = 0;

    void MouseControls()
    {
        // Get Main Camera:
        Camera main = Camera.main;

        // Player Input:
        xInput += Input.GetAxis("Mouse X") * mouseSensitivity;
        
        yInput += Input.GetAxis("Mouse Y") * mouseSensitivity;

        // Clamp the Y Axis as we don't want full 360 rotation:
        yInput = Mathf.Clamp(yInput, -mouseYLock, mouseYLock);

        // Player Rotation:
        Vector3 newRotation = new Vector3(0, xInput, 0);
        rb.MoveRotation(Quaternion.Euler(newRotation));

        // Camera Rotation:
        Vector3 newCamRot = new Vector3(-yInput, main.transform.eulerAngles.y, main.transform.eulerAngles.z);
        main.transform.eulerAngles = newCamRot;

    }

    /// <summary>
    ///  Used to Quit the Prototype
    /// </summary>
    private void Exit()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }
    }


}