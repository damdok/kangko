using System.Collections.Generic;
using System.Linq;
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using DecalSystem;
using UnityEngine.UI;

/// <summary>
///  This script deals with placing, rotating and scaling images.
/// </summary>
public class PlaceImage : MonoBehaviour {

    [Header("Player Settings")]
    public float rotationSpeed;
    [Range(0, 10)]
    public float range;

    [Header("Images")]
    public Sprite[] listOfImages;
    public int currentSprite = 0;

    [Header("Image Settings")]
    public float rotation = 0;
    [HideInInspector] public bool isRotating = false;
    public float scaler = 1;

    [Header("Image Prefab")]
    public GameObject decalPrefab;

    [Header("Preview Image")]
    public Decal testDecal;

    [Header("Inventory")]
    public GameObject inventoryUI;

    public static PlaceImage instance = null;


    [Header("UI Mouse Edges")]
    public List<Image> edges;

    bool canPlace = true;

    // Basic Colours:
    Color32 green;
    Color32 red;
    Color32 white;


    //Awake is always called before any Start functions
    void Awake()
    {
        //Check if instance already exists
        if (instance == null)
        {
            //if not, set instance to this
            instance = this;
        }

        //If instance already exists and it's not this:
        else if (instance != this)
        {
            //Then destroy this. This enforces our singleton pattern, meaning there can only ever be one instance of this.
            Destroy(gameObject);
        }
    }

    // Use this for initialization
    void Start() {
        // Set Up Colours:
        green = new Color32(184, 255, 163, 245);
        red = new Color32(255, 181, 148, 245);
        white = new Color32(245, 245, 245, 245);

        // Set Current Image on Preview:
        testDecal.Sprite = listOfImages[currentSprite]; 
    }
	
	// Update is called once per frame
	void Update ()
    {
        // Check if user wants to open up Inventory:
        OpenInv();

        // If the Inventory isn't open:
        if (!openUI)
        {
            // Can Place, Remove, Scale, Change or Rotate the image:
            Place();
            Remove();
            Scale();
            Change();
            Rotate();
        }
    }

    /// <summary>
    /// Changes the current Image:
    /// </summary>
    public void Change()
    {
        // When Q is pressed:
        if (Input.GetKeyDown(KeyCode.Q))
        {
            // Go to previous image:
            currentSprite--;

            // Check if that image is on the list:
            if (currentSprite < 0)
            {
                // If not, return to last image.
                currentSprite = listOfImages.Length - 1;                    
            }

            // Set Image:
            testDecal.Sprite = listOfImages[currentSprite];
        }

        // When E is pressed:
        if (Input.GetKeyDown(KeyCode.E))
        {
            // Go to next Image:
            currentSprite++;

            // Check if that image exists:
            if (currentSprite == listOfImages.Length)
            {
                // If not, go to first image.
                currentSprite = 0;

            }

            // Set Image:
            testDecal.Sprite = listOfImages[currentSprite];
        }
    }

    /// <summary>
    /// Removes the Image off a wall
    /// </summary>
    public void Remove()
    {
        RaycastHit hit;
        // Does the ray intersect any objects excluding the player layer
        if (Physics.Raycast(Camera.main.transform.position, Camera.main.transform.TransformDirection(Vector3.forward), out hit, range, LayerMask.GetMask("Decal")))
        {
            // If you are looking at a Image:
            if (hit.collider.tag == "Decal")
            {
                // If the Delete key is pressed. Remove Image:
                if (Input.GetKeyDown(KeyCode.Delete))
                {
                    Destroy(hit.collider.gameObject);
                    TestDecal.instance.SetPlace(true);
                }
            }
        }
    }

    /// <summary>
    ///  Places the Image onto a wall
    /// </summary>
    public void Place()
    {
        RaycastHit hit;
        int layerMask = 1;
        // Does the ray intersect any objects excluding the player layer
        if (Physics.Raycast(Camera.main.transform.position, Camera.main.transform.TransformDirection(Vector3.forward), out hit, range, layerMask))
        {
            // If the object we are looking at is tagged with Placeable:
            if (hit.collider.tag == "Placeable")
            {
                // Move the Preview Image to that location:
                MovePre(hit);

                /* This is used to prevent Overlapping Images:
                 * 
                if (TestDecal.instance.CanPlace())
                {
                    canPlace = true;
                    ChangeColour(green);
                }
                else
                {
                    ChangeColour(red);
                    canPlace = false;
                }
                */

                canPlace = true;
                // Change the UI mouse green:
                ChangeColour(green);
            }
            else
            {
                // Change the UI mouse red:
                ChangeColour(red);
                // Get rid of the preview image:
                testDecal.transform.position += Vector3.up * 1000;
                canPlace = false;
            }

            // If the user preses the left mouse button down:
            if (Input.GetMouseButtonDown(0))
            {
                // If the object in front of the player is placeable:
                if (canPlace)
                {
                    // Create a new image at that location:
                    GameObject newImage = Instantiate(decalPrefab, hit.point, Quaternion.identity) as GameObject;
                    // Set the Size:
                    newImage.transform.localScale = Vector3.one * scaler; 
                    // Set the Transform:
                    SetTransform(newImage.transform, hit.point, -hit.normal);
                    // Set the Rotation:
             		newImage.transform.eulerAngles = new Vector3 (newImage.transform.eulerAngles.x, newImage.transform.eulerAngles.y, rotation);
                    // Add a collider:
                    newImage.AddComponent<BoxCollider>();
                    // Get the Image:
                    Decal newDecal = newImage.GetComponent<Decal>();
                    // Change the Image:
                    newDecal.Sprite = listOfImages[currentSprite];
                    // Build Image:
                    newDecal.BuildAndSetDirty();
                }
            }   
        }
        else
        {
            // If you are looking at nothing:
            testDecal.transform.position += Vector3.up * 1000;
            ChangeColour(white);
        }
    }

    // Setting the Transform:
    void SetTransform(Transform transform, Vector3 position, Vector3 normal)
    {
        transform.position = position;
        transform.forward = normal;
    }


    // Setting the Scale based of the mouse scroll wheel:
    public void Scale()
    {
        scaler += Input.GetAxis("Mouse ScrollWheel") * Time.deltaTime * 20;

        scaler = Mathf.Clamp(scaler,0,5);
        testDecal.gameObject.transform.localScale = Vector3.one * scaler; 
    }


    
    // Setting the rotation:
    public void Rotate()
    {
    	if(Input.GetMouseButton(1))
    	{
    		isRotating = true;
    		rotation+= Input.GetAxis("Mouse X") * rotationSpeed;
    		testDecal.transform.eulerAngles = new Vector3 (testDecal.transform.eulerAngles.x, testDecal.transform.eulerAngles.y, rotation);
    	}
        else
        {
    		isRotating = false;
    	}
    }

    // Changing the color of the UI mouse:
    void ChangeColour(Color color)
    {
        foreach (Image edge in edges)
        {
            edge.color = color;
        }
    }

    // Moving the Preview Image:
    void MovePre(RaycastHit hit)
    {
        SetTransform(testDecal.gameObject.transform, hit.point, -hit.normal);
        testDecal.transform.eulerAngles = new Vector3 (testDecal.transform.eulerAngles.x, testDecal.transform.eulerAngles.y, rotation);
        testDecal.BuildAndSetDirty();
    }

    // Opening up the Image Inventory:
    [HideInInspector]public bool openUI = false;
    void OpenInv()
    {
        // If I is pressed:
        if (Input.GetKeyDown(KeyCode.I))
        {
            // Open / Close:
            openUI = !openUI;

            // If Open:
            if (openUI)
            {
                // Make Inventory visable:
                inventoryUI.SetActive(true);

                // Fill in Input Boxes with correct values:
                inventoryUI.GetComponentInChildren<Inventory>().SetValuescale(scaler);
                inventoryUI.GetComponentInChildren<Inventory>().SetValueRotation(rotation);

                // Make the cursor visable:
                Cursor.visible = true;
                Cursor.lockState = CursorLockMode.None;

                // Pause GamePlay:
                Time.timeScale = 0;
            }
            // If Close:
            else
            {
                // Make Inventory invisable:
                inventoryUI.SetActive(false);
                // Hide Cursor:
                Cursor.visible = false;
                Cursor.lockState = CursorLockMode.Locked;
                // Unpause Gameplayer:
                Time.timeScale = 1;
            }
        }
    }


}
