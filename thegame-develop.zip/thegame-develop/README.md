Controlls:
WASD - Movement.
Q - Go back a image.
E - Go forward a image.
Delete - Delete a Image.
Scrollwheel - Change Size.
I - Inventory.
Right Click - Rotate Image.
Left CLick - Place Image.
ESC - Quit
